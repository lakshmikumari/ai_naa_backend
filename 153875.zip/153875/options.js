var listE = new DynamicOptionList("E","D");
listE.addOptions("Summary Documents"
  ,"Executive Summary", "summary/Audit_Summary"
  ,"Executive Summary Statistics Excel", "summary/Audit_Summary_Excel"
  ,"Cisco Nexus Platform Audit Detailed Findings", "summary/Nexus_Platform_Audit_Detailed_Findings"
  ,"Cisco Nexus Routing Platform Audit Detailed Findings", "summary/Nexus_Routing_Protocol_Audit_Detailed_Findings");

listE.addOptions("Complete List"
  ,"N9K-1 - Cisco Nexus Platform Audit Detailed Findings - Node Based", "501034548/Nexus_Platform_Audit_Detailed_Findings"
  ,"N9K-1 - Cisco Nexus Routing Platform Audit Detailed Findings - Node Based", "501034548/Nexus_Routing_Protocol_Audit_Detailed_Findings");

listE.addOptions("Cisco Nexus 9000 Series Switches"
  ,"N9K-1 - Cisco Nexus Platform Audit Detailed Findings - Node Based", "501034548/Nexus_Platform_Audit_Detailed_Findings"
  ,"N9K-1 - Cisco Nexus Routing Platform Audit Detailed Findings - Node Based", "501034548/Nexus_Routing_Protocol_Audit_Detailed_Findings");

function    initTitle() {
    document.getElementById("auditType").innerHTML = "Cisco Nexus Platform Audit";
    document.getElementById("companyName").innerHTML = "CISCO CSTG INTERNAL - SUPPORT";
}

function addCategories(category) {
    var oOption;
    var options = category.options;

    oOption = document.createElement("OPTION");
    oOption.text="Cisco Nexus 9000 Series Switches";
    oOption.value="Cisco Nexus 9000 Series Switches";
    options[options.length] = oOption;

}
